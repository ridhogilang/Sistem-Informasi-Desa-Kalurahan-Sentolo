<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1><?php echo e($title); ?></h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/admin/e-surat/dashboard">Home</a></li>
                <li class="breadcrumb-item active"><?php echo e($title); ?></li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section">
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="card-title">Data <?php echo e($title); ?></h5>
                        </div>

                        <!-- Table with hoverable rows -->
                        <table class="table table-hover datatable">
                            <thead>
                                <tr>
                                    <th scope="col" class="text-center">No.</th>
                                    <th scope="col" class="text-center">Nomor Surat</th>
                                    <th scope="col" class="text-center">Jenis Surat</th>
                                    <th scope="col" class="text-center">Status</th>
                                    <th scope="col" class="text-center">Isi Surat</th>
                                    <th scope="col" class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($value['nomor_surat']); ?></td>
                                        <td><?php echo e($value['jenis_surat']); ?></td>
                                        <td class="text-center"><?php echo $badge_status[$value['status']]; ?></td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('bo.surat.validasi.show', $value['id'])); ?>" target="blank" class="btn btn-primary">
                                                <i class="bi bi-file-earmark"></i>
                                            </a>
                                        </td>
                                        <td class="text-center">
                                            <div class="d-flex justify-content-evenly">
                                                <form action="<?php echo e(route('bo.surat.validasi.update', $value['id'])); ?>" method="POST">
                                                    <?php echo method_field('put'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button class="btn btn-success" type="submit"><i class="bi bi-check-lg"></i></button>
                                                </form>

                                                <form action="<?php echo e(route('bo.surat.validasi.destroy', $value['id'])); ?>" method="POST">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button class="btn btn-danger"  type="submit"><i class="bi bi-x-lg"></i></button>
                                                </form>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- End Table with hoverable rows -->

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bo.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_sentolo\sentolo_gab_si\resources\views/bo/page/surat/validasi/index.blade.php ENDPATH**/ ?>