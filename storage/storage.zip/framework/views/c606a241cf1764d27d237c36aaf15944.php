<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Surat Masuk</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/admin/e-surat/dashboard">Home</a></li>
                <li class="breadcrumb-item active">Surat Masuk</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section">
        <div class="row">

            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="card-title">Data Surat Masuk</h5>
                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#tambah-surat-masuk"><i class="fa-regular fa-square-plus" style="margin-right: 5px"></i>Tambah Data</button>

                            <!-- Modal -->
                            <div class="modal fade" id="tambah-surat-masuk" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="tambah-surat-masuk-Label" aria-hidden="true">
                                <div class="modal-dialog modal-lg ">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="tambah-surat-masuk-Label">Data Surat Masuk</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form class="row" action="/admin/e-surat/surat-masuk" method="POST" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="row mb-3">
                                                    <label for="nomor_surat" class="col-sm-3 col-form-label">Nomor Surat</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="nomor_surat" name="nomor_surat" placeholder="<?php echo e($TemplateNoSurat); ?>" value="<?php echo e(old('nomor_surat')); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="judul_surat" class="col-sm-3 col-form-label">Judul Surat</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="judul_surat" name="judul_surat" value="<?php echo e(old('judul_surat')); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="tanggal_surat" class="col-sm-3 col-form-label">Tanggal Surat</label>
                                                    <div class="col-sm-9">
                                                        <input type="date" class="form-control" id="tanggal_surat" name="tanggal_surat" value="<?php echo e(old('tanggal_surat')); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="Kepada" class="col-sm-3 col-form-label">Kepada</label>
                                                    <div class="col-sm-9">
                                                        <select id="Kepada" name="kepada" class="form-select" required>
                                                            <option value="" disabled selected>Pilih Pejabat yang Menerima Surat</option>
                                                            <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($value['id'].'/'.$value['jabatan']); ?>"><?php echo e($value['nama'] . ' ( ' . $value['jabatan'] . ' )'); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="keperluan" class="col-sm-3 col-form-label">Keperluan</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="keperluan" name="keperluan" value="<?php echo e(old('keperluan')); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="tanggal_kegiatan" class="col-sm-3 col-form-label">Tanggal Kegiatan</label>
                                                    <div class="col-sm-9">
                                                        <input type="date" class="form-control" id="tanggal_kegiatan" name="tanggal_kegiatan" value="<?php echo e(old('tanggal_kegiatan')); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="catatan" class="col-sm-3 col-form-label">Catatan</label>
                                                    <div class="col-sm-9">
                                                        <textarea type="text" name="catatan" class="form-control" id="catatan" rows="2" required><?php echo e(old('catatan')); ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="lampiran" class="col-sm-3 col-form-label">Lampiran</label>
                                                    <div class="col-sm-9">
                                                        <textarea type="text" name="lampiran" class="form-control" id="lampiran" rows="2" required><?php echo e(old('lampiran')); ?> </textarea>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="dokumen" class="col-sm-3 col-form-label">Dokumen</label>
                                                    <div class="col-sm-9">
                                                        <input type="file" name="dokumen" class="form-control" id="dokumen" accept=".doc, .docx, .pdf, .xls, .xlsx, .ppt, .pptx" value="<?php echo e(old('dokumen')); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Table with hoverable rows -->
                        <table class="table table-hover datatable">
                            <thead>
                                <tr>
                                    <th scope="col">No.</th>
                                    <th scope="col">Nomor Surat</th>
                                    <th scope="col">Kepada</th>
                                    <th scope="col">Keperluan</th>
                                    <th scope="col">Tanggal Kegiatan</th>
                                    <th scope="col">Status</th>
                                    <th scope="col" class="text-center">Dokumen</th>
                                    <th scope="col" class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $no = 1;
                                ?>
                                <?php $__currentLoopData = $smasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($no++); ?>.</th>
                                        <td><?php echo e($value->nomor_surat); ?></td>
                                        <td><?php echo e($value->kepada_detil->nama.' ( '. $value->kepada_jabatan .' )'); ?></td>
                                        <td><?php echo e($value->keperluan); ?></td>
                                        <td><?php echo e($value->tanggal_kegiatan); ?><br>
                                        </td>
                                        <td class="text-center">
                                            <a data-bs-toggle="modal" data-bs-target="#status_<?php echo e($value->id); ?>" class="btn btn-primary">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        </td>
                                        <!-- ini bagian modal riwayat surat -->
                                        <div class="modal fade" id="status_<?php echo e($value->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg modal-dialog-scrollable">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Riwayat Surat <?php echo e($value->nomor_surat); ?></h5>
                                                        <div class="mx-3"><?php echo $badge_disposisi_status[$value->status_surat]; ?></div>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="container">
                                                            <?php
                                                                $pamongDps[$value->id][] = '-';
                                                            ?>
                                                            <?php $__currentLoopData = $value->detilDisposisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detildis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="row border-bottom p-3">
                                                                <div class="col">
                                                                    Diterima : <?php echo e($detildis->tgl_diterima_dari_disposisi); ?><br>
                                                                    <?php if(auth()->user()->id == $detildis->id_user): ?>
                                                                        Anda <br>
                                                                    <?php elseif($detildis->id_user == 'PU'): ?>
                                                                        ( <?php echo e($detildis->jabatan_user); ?> )<br>
                                                                    <?php else: ?>
                                                                        <?php echo e($detildis->pamongDPSS->nama); ?> ( <?php echo e($detildis->jabatan_user); ?> )<br>
                                                                    <?php endif; ?>
                                                                    <!-- memilih status -->
                                                                    <?php if($detildis->id_user == 'PU'): ?>
                                                                        Surat Dianalisis ulang oleh Pelayanan Umum
                                                                    <?php elseif($detildis->status_disposisi == '1' || $detildis->status_disposisi == '4'): ?>
                                                                        <?php echo ($detildis->jenis_disposisi == 'PLK')?$badge_disposisi_status['4']:''; ?>


                                                                        <?php echo $badge_disposisi_status[$detildis->status_disposisi]; ?>


                                                                    <?php else: ?>
                                                                    Tindakan : <?php echo e($detildis->tgl_dilanjutkan_ke_disposisi); ?><br>
                                                                        <?php echo ($detildis->jenis_disposisi == 'PLK')?$badge_disposisi_status['4']:''; ?>

                                                                        <?php echo $badge_disposisi_status[$detildis->status_disposisi]; ?> <?php echo e($detildis->catatan); ?>

                                                                    <?php endif; ?>

                                                                </div>
                                                            </div>
                                                            <?php

                                                                $id_dtl[$value->id] = $detildis->id;
                                                                $id_jns[$value->id] = $detildis->jenis_disposisi;

                                                            ?>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <td class="text-center">
                                            <a class="btn btn-success" target="blank" type="submit" href="/admin/e-surat/surat-masuk/<?php echo e($value->id); ?>/document"><i class="fa-solid fa-file-arrow-down"></i></a>
                                        </td>
                                        <td class="text-center">
                                            <div class="d-flex">
                                                <!-- Button trigger modal -->
                                                <?php if(($value->status_surat == '3' || $value->status_surat == '1')): ?>
                                                    <a class="btn btn-warning mx-1" type="submit" data-bs-toggle="modal" data-bs-target="#Modal-Edit-SMasuk<?php echo e($value->id); ?>" href="/admin/e-surat/surat-masuk/<?php echo e($value->id); ?>"><i class="fa-solid fa-pen-to-square"></i></a>
                                                <?php else: ?>
                                                    <a class="btn btn-secondary mx-1" href="#"><i class="fa-solid fa-pen-to-square"></i></a>
                                                <?php endif; ?>
                                                <!-- untuk methode delete lebih baik menggunakan put / delete jangan menggunakan get -->
                                                <?php if(($tgl_hr_ini > $value->tanggal_kegiatan) || ($value->status_surat == '3')): ?>
                                                    <button data-bs-toggle="modal" data-bs-target="#arsip_sm_<?php echo e($value->id); ?>" type="button" class="btn btn-danger mx-1">
                                                        <i class="fa-solid fa-circle-up"></i>
                                                    </button>
                                                <?php else: ?>
                                                    <a class="btn btn-secondary mx-1"><i class="fa-solid fa-circle-up"></i></a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php if(($value->status_surat == '3' || $value->status_surat == '1')): ?>
                                        <!-- Modal Edit SURAT MASUK-->
                                        <div class="modal fade" id="Modal-Edit-SMasuk<?php echo e($value->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="Modal-Edit-SMasuk" aria-hidden="true">
                                            <div class="modal-dialog modal-lg modal-dialog-scrollable">
                                                <div class="modal-content">
                                                    <form action="/admin/e-surat/surat-masuk/<?php echo e($value->id); ?>" method="POST" enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('put'); ?>
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="Modal-Edit-SMasuk">Edit Data Surat Masuk <?php echo e($value->nomor_surat); ?></h1>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row mb-3">
                                                                <label for="nomor_surat3" class="col-sm-3 col-form-label">Nomor Surat</label>
                                                                <div class="col-sm-9">
                                                                    <input type="text" class="form-control" id="nomor_surat3" name="nomor_surat" value="<?php echo e($value->nomor_surat); ?>" required>
                                                                </div>
                                                            </div>
                                                            <div class="row mb-3">
                                                                <label for="judul_surat3" class="col-sm-3 col-form-label">Judul Surat</label>
                                                                <div class="col-sm-9">
                                                                    <input type="text" class="form-control" id="judul_surat3" name="judul_surat" value="<?php echo e($value->judul_surat); ?>" required>
                                                                </div>
                                                            </div>
                                                            <div class="row mb-3">
                                                                <label for="tanggal_surat3" class="col-sm-3 col-form-label">Tanggal Surat</label>
                                                                <div class="col-sm-9">
                                                                    <input type="date" name="tanggal_surat" class="form-control" id="tanggal_surat3" value="<?php echo e($value->tanggal_surat); ?>" required>
                                                                </div>
                                                            </div>
                                                            <div class="row mb-3">
                                                                <label for="Kepada" class="col-sm-3 col-form-label">Kepada</label>
                                                                <div class="col-sm-9">
                                                                    <select id="Kepada" name="kepada" class="form-select" required>
                                                                        <option value="" disabled selected>Pilih Pejabat yang Menerima Surat</option>
                                                                        <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pamong): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($pamong['id'].'/'.$pamong['jabatan']); ?>" <?php echo e(($value->kepada_id_user == $pamong['id'])?'selected':''); ?>><?php echo e($pamong['nama'] . ' ( ' . $pamong['jabatan'] . ' )'); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="row mb-3">
                                                                <label for="keperluan3" class="col-sm-3 col-form-label">Keperluan</label>
                                                                <div class="col-sm-9">
                                                                    <input type="text" name="keperluan" class="form-control" id="keperluan3" value="<?php echo e($value->keperluan); ?>" required>
                                                                </div>
                                                            </div>
                                                            <div class="row mb-3">
                                                                <label for="tanggal_kegiatan3" class="col-sm-3 col-form-label">Tanggal Kegiatan</label>
                                                                <div class="col-sm-9">
                                                                    <input type="date" name="tanggal_kegiatan" class="form-control" id="tanggal_kegiatan3" value="<?php echo e($value->tanggal_kegiatan); ?>" required>
                                                                </div>
                                                            </div>
                                                            <div class="row mb-3">
                                                                <label for="catatan3" class="col-sm-3 col-form-label">Catatan</label>
                                                                <div class="col-sm-9">
                                                                    <textarea type="text" name="catatan" class="form-control" id="catatan3" rows="2" required><?php echo e($value->catatan); ?></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="row mb-3">
                                                                <label for="lampiran3" class="col-sm-3 col-form-label">Lampiran</label>
                                                                <div class="col-sm-9">
                                                                    <textarea type="text" name="lampiran" class="form-control" id="lampiran3" rows="2" required><?php echo e($value->lampiran); ?></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <label for="dokumen3" class="col-sm-3 col-form-label">Dokumen</label>
                                                                <div class="col-sm-9">
                                                                    <input type="file" name="dokumen" class="form-control" id="dokumen3" value="<?php echo e($value->dokumen); ?>" >
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(($tgl_hr_ini > $value->tanggal_kegiatan) || ($value->status_surat == '3')): ?>
                                        <!-- Modal Arsip SURAT MASUK-->
                                        <div class="modal fade" id="arsip_sm_<?php echo e($value->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg modal-dialog-scrollable">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Arsipkan Surat <?php echo e($value->nomor_surat); ?></h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <form method="POST" action="/admin/e-surat/surat-masuk/<?php echo e($value->id); ?>/delete">
                                                        <?php echo method_field('delete'); ?>
                                                        <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        <div class="container">


                                                            <div class="row mb-3">
                                                                <div class="col">
                                                                    <p>Berikan catatan mengapa Surat <?php echo e($value->nomor_surat); ?> gagal dilaksanakan</p>
                                                                </div>
                                                            </div>

                                                            <div class="row mb-3">
                                                                <label for="catatan" class="col-sm-3 col-form-label">Catatan</label>
                                                                <div class="col-sm-9">
                                                                    <textarea name="catatan" class="form-control" id="catatan" rows="5" required></textarea>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-danger">
                                                            Arsipkan
                                                        </button>
                                                    </div>
                                                </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- End Table with hoverable rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bo.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_sentolo\sentolo_gab_si\resources\views/bo/page/surat/masuk/surat-masuk.blade.php ENDPATH**/ ?>