<?php $__env->startPush('scripts'); ?>
    <script>
        // Mendapatkan elemen input NIK
        var nikInput = document.getElementById('nik');
        // Mendapatkan elemen input NIK Orang 1
        var nik_satuInput = document.getElementById('nik_satu');
        // Mendapatkan elemen input NIK Orang 2
        var nik_duaInput = document.getElementById('nik_dua');

        // Menambahkan event listener ketika nilai input NIK berubah
        nikInput.addEventListener('input', function() {
            var nik = this.value;

            // Buat permintaan AJAX untuk mengambil data berdasarkan NIK
            var xhr = new XMLHttpRequest();
            xhr.open('GET', '/get-penduduk/' + nik, true);

            xhr.onload = function() {
                if (xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);

                    // Daftar elemen form yang ingin Anda isi
                    var formElements = ['nama', 'jenis_kelamin', 'tempat_lahir', 'tanggal_lahir', 'agama', 'status_perkawinan', 'alamat', 'kewarganegaraan', 'pekerjaan', 'pendidikan_terakhir', 'nomor_telepon', 'penghasilan', 'foto_penduduk', 'nomor_kk', 'nomor_ktp', 'status_nyawa', 'keterangan_kematian', 'kontak_darurat', 'status_migrasi', 'status_pajak'];

                    // Loop melalui elemen form dan isi nilainya jika ada dalam data
                    formElements.forEach(function(element) {
                        if (document.getElementById(element)) {
                            document.getElementById(element).value = data[element] || '';
                        }
                    });
                } else {
                    // Handle jika NIK tidak ditemukan
                    formElements.forEach(function(element) {
                        if (document.getElementById(element)) {
                            document.getElementById(element).value = '';
                        }
                    });
                }
            };

            xhr.send();
        });

        // Menambahkan event listener ketika nilai input NIK berubah Orang 1
        nik_satuInput.addEventListener('input', function() {
            var nik_satu = this.value;

            // Buat permintaan AJAX untuk mengambil data berdasarkan NIK
            var xhr = new XMLHttpRequest();
            xhr.open('GET', '/get-penduduk/' + nik_satu, true);

            xhr.onload = function() {
                if (xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);

                    // Isi input dengan data yang diterima
                    if (document.getElementById('nama_satu')) {
                        document.getElementById('nama_satu').value = data.nama || '';
                    }
                    if (document.getElementById('tempat_lahir_satu')) {
                        document.getElementById('tempat_lahir_satu').value = data.tempat_lahir || '';
                    }
                    if (document.getElementById('tanggal_lahir_satu')) {
                        document.getElementById('tanggal_lahir_satu').value = data.tanggal_lahir || '';
                    }
                    if (document.getElementById('agama_satu')) {
                        document.getElementById('agama_satu').value = data.agama || '';
                    }
                    if (document.getElementById('pekerjaan_satu')) {
                        document.getElementById('pekerjaan_satu').value = data.pekerjaan || '';
                    }
                    if (document.getElementById('alamat_satu')) {
                        document.getElementById('alamat_satu').value = data.alamat || '';
                    }
                } else {
                    // Handle jika NIK tidak ditemukan
                    document.getElementById('nama_satu').value = '';
                    document.getElementById('tempat_lahir_satu').value = '';
                    document.getElementById('tanggal_lahir_satu').value = '';
                    document.getElementById('agama_satu').value = '';
                    document.getElementById('pekerjaan_satu').value = '';
                    document.getElementById('alamat_satu').value = '';
                }
            };

            xhr.send();
        });

        // Menambahkan event listener ketika nilai input NIK berubah Orang 2
        nik_duaInput.addEventListener('input', function() {
            var nik_dua = this.value;

            // Buat permintaan AJAX untuk mengambil data berdasarkan NIK
            var xhr = new XMLHttpRequest();
            xhr.open('GET', '/get-penduduk/' + nik_dua, true);

            xhr.onload = function() {
                if (xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);

                    // Isi input dengan data yang diterima
                    if (document.getElementById('nama_dua')) {
                        document.getElementById('nama_dua').value = data.nama || '';
                    }
                    if (document.getElementById('tempat_lahir_dua')) {
                        document.getElementById('tempat_lahir_dua').value = data.tempat_lahir || '';
                    }
                    if (document.getElementById('tanggal_lahir_dua')) {
                        document.getElementById('tanggal_lahir_dua').value = data.tanggal_lahir || '';
                    }
                    if (document.getElementById('agama_dua')) {
                        document.getElementById('agama_dua').value = data.agama || '';
                    }
                    if (document.getElementById('pekerjaan_dua')) {
                        document.getElementById('pekerjaan_dua').value = data.pekerjaan || '';
                    }
                    if (document.getElementById('alamat_dua')) {
                        document.getElementById('alamat_dua').value = data.alamat || '';
                    }
                } else {
                    // Handle jika NIK tidak ditemukan
                    document.getElementById('nama_dua').value = '';
                    document.getElementById('tempat_lahir_dua').value = '';
                    document.getElementById('tanggal_lahir_dua').value = '';
                    document.getElementById('agama_dua').value = '';
                    document.getElementById('pekerjaan_dua').value = '';
                    document.getElementById('alamat_dua').value = '';
                }
            };

            xhr.send();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1>Surat Keterangan Tidak Mampu</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/admin/e-surat/dashboard">Home</a></li>
            <li class="breadcrumb-item">Surat Keluar</li>
            <li class="breadcrumb-item active">Keterangan Tidak Mampu</li>
        </ol>
    </nav>
</div><!-- End Page Title -->

<section class="section">
    <div class="row">

        <div class="col-lg-12">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['input surat', 'lihat contoh surat'])): ?>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Pilih Jenis Surat Keterangan Tidak Mampu</h5>

                    <div class="d-flex justify-content-between">

                        <div>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('input surat')): ?>
                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#sktm-satu"><i class="fa-regular fa-square-plus" style="margin-right: 5px"></i>Buat Surat 1 Orang</button>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lihat contoh surat')): ?>
                            <a class="btn btn-success btn-sm" type="submit" target="blank" href="/admin/e-surat/contoh-surat-ktm-satu/view"><i class="fa-solid fa-print" style="margin-right: 5px"></i>Contoh Surat 1 Orang</a>
                            <?php endif; ?>
                        </div>

                        <div>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('input surat')): ?>
                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#sktm-dua"><i class="fa-regular fa-square-plus" style="margin-right: 5px"></i>Buat Surat 2 Orang</button>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lihat contoh surat')): ?>
                            <a class="btn btn-success btn-sm" type="submit" target="blank" href="/admin/e-surat/contoh-surat-ktm-dua/view"><i class="fa-solid fa-print" style="margin-right: 5px"></i>Contoh Surat 2 Orang</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('input surat')): ?>
                    <!-- Modal Form 1 Orang -->
                    <div class="modal fade" id="sktm-satu" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="sktm-satu-Label" aria-hidden="true">
                        <div class="modal-dialog modal-lg modal-dialog-scrollable">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="sktm-satu-Label">Data Surat Keterangan Tidak Mampu 1 Orang</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form class="row" action="/admin/e-surat/surat-ktm-satu" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="row mb-3">
                                            <label for="nomor_surat" class="col-sm-3 col-form-label">Nomor Surat</label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control" id="nomor_surat" name="nomor_surat" value="<?php echo e($TemplateNoSurat); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="nik" class="col-sm-3 col-form-label">NIK</label>
                                            <div class="col-sm-9">
                                                <input type="number" name="nik" class="form-control" id="nik" minlength="16" value="<?php echo e(old('nik')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="nama" class="col-sm-3 col-form-label">Nama</label>
                                            <div class="col-sm-9">
                                                <input type="text" name="nama" class="form-control" id="nama" value="<?php echo e(old('nama')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="jenis_kelamin" class="col-sm-3 col-form-label">Jenis Kelamin</label>
                                            <div class="col-sm-9">
                                                <select id="jenis_kelamin" name="jenis_kelamin" class="form-select" required>
                                                    <option value="" <?php if(old('jenis_kelamin')=='' ): ?> selected <?php endif; ?>>Pilih Jenis Kelamin ...</option>
                                                    <option value="Laki-laki" <?php if(old('jenis_kelamin')=='Laki-laki' ): ?> selected <?php endif; ?>>Laki-laki</option>
                                                    <option value="Perempuan" <?php if(old('jenis_kelamin')=='Perempuan' ): ?> selected <?php endif; ?>>Perempuan</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="tempat_lahir" class="col-sm-4 col-form-label">Tempat / Tanggal Lahir</label>
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control" id="tempat_lahir" name="tempat_lahir" value="<?php echo e(old('tempat_lahir')); ?>" required>
                                            </div>
                                            <label for="tanggal_lahir" class="col-sm-1 col-form-label text-center">/</label>
                                            <div class="col-sm-3">
                                                <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="agama" class="col-sm-3 col-form-label">Agama</label>
                                            <div class="col-sm-9">
                                                <select id="agama" name="agama" class="form-select" required>
                                                    <option value="" <?php if(old('agama')=='' ): ?> selected <?php endif; ?>>Pilih Agama ...</option>
                                                    <option value="Islam" <?php if(old('agama')=='Islam' ): ?> selected <?php endif; ?>>Islam</option>
                                                    <option value="Kristen Protestan" <?php if(old('agama')=='Kristen Protestan' ): ?> selected <?php endif; ?>>Kristen Protestan</option>
                                                    <option value="Kristen Katolik" <?php if(old('agama')=='Kristen Katolik' ): ?> selected <?php endif; ?>>Kristen Katolik</option>
                                                    <option value="Hindu" <?php if(old('agama')=='Hindu' ): ?> selected <?php endif; ?>>Hindu</option>
                                                    <option value="Buddha" <?php if(old('agama')=='Buddha' ): ?> selected <?php endif; ?>>Buddha</option>
                                                    <option value="Konghucu" <?php if(old('agama')=='Konghucu' ): ?> selected <?php endif; ?>>Konghucu</option>
                                                    <option value="Lainnya" <?php if(old('agama')=='Lainnya' ): ?> selected <?php endif; ?>>Lainnya</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="status_perkawinan" class="col-sm-3 col-form-label">Status Perkawinan</label>
                                            <div class="col-sm-9">
                                                <select id="status_perkawinan" name="status_perkawinan" class="form-select" required>
                                                    <option value="" <?php if(old('status_perkawinan')=='' ): ?> selected <?php endif; ?>>Pilih Status Perkawinan ...</option>
                                                    <option value="Belum Menikah" <?php if(old('status_perkawinan')=='Belum Menikah' ): ?> selected <?php endif; ?>>Belum Menikah</option>
                                                    <option value="Sudah Menikah" <?php if(old('status_perkawinan')=='Sudah Menikah' ): ?> selected <?php endif; ?>>Sudah Menikah</option>
                                                    <option value="Janda" <?php if(old('status_perkawinan')=='Janda' ): ?> selected <?php endif; ?>>Janda</option>
                                                    <option value="Duda" <?php if(old('status_perkawinan')=='Duda' ): ?> selected <?php endif; ?>>Duda</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="pekerjaan" class="col-sm-3 col-form-label">Pekerjaan</label>
                                            <div class="col-sm-9">
                                                <input type="text" name="pekerjaan" class="form-control" id="pekerjaan" value="<?php echo e(old('pekerjaan')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="alamat" class="col-sm-3 col-form-label">Alamat</label>
                                            <div class="col-sm-9">
                                                <input type="text" name="alamat" class="form-control" id="alamat" value="<?php echo e(old('alamat')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="deskripsi" class="col-sm-3 col-form-label">Deskripsi</label>
                                            <div class="col-sm-9">
                                                <textarea type="text" name="deskripsi" class="form-control" id="deskripsi" rows="3" required>Bahwa bersangkutan tersebut adalah benar dari keluarga kurang mampu.</textarea>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="tanda_tangan" class="col-sm-3 col-form-label">Tanda Tangan</label>
                                            <div class="col-sm-9">
                                                <select id="tanda_tangan" name="tanda_tangan[]" class="form-select" required>
                                                    <option value="" disabled selected>Pilih Pejabat yang Bertanda tangan</option>
                                                    <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value['id'].'/'.$value['nama'].'/'.$value['jabatan']); ?>"><?php echo e($value['nama'] . ' ( ' . $value['jabatan'] . ' )'); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <label for="mengetahui" class="col col-form-label">Pejabat Yang mengetahui</label>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-4 mb-3">
                                                <select id="mengetahui[]" name="mengetahui[]" class="form-select" required>
                                                    <option value="" disabled selected>Pilih Pejabat yang Mengetahui</option>
                                                    <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value['id'].'/'.$value['nama'].'/'.$value['jabatan']); ?>"><?php echo e($value['nama'] . ' ( ' . $value['jabatan'] . ' )'); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <select id="mengetahui[]" name="mengetahui[]" class="form-select">
                                                    <option value="" selected>Pilih Pejabat yang Mengetahui</option>
                                                    <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value['id'].'/'.$value['nama'].'/'.$value['jabatan']); ?>"><?php echo e($value['nama'] . ' ( ' . $value['jabatan'] . ' )'); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-md-4">
                                                <select id="mengetahui[]" name="mengetahui[]" class="form-select">
                                                    <option value="" selected>Pilih Pejabat yang Mengetahui</option>
                                                    <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value['id'].'/'.$value['nama'].'/'.$value['jabatan']); ?>"><?php echo e($value['nama'] . ' ( ' . $value['jabatan'] . ' )'); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('input surat')): ?>
                    <!-- Modal Form 2 Orang -->
                    <div class="modal fade" id="sktm-dua" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="sktm-dua-Label" aria-hidden="true">
                        <div class="modal-dialog modal-lg modal-dialog-scrollable">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="sktm-dua-Label">Data Surat Keterangan Tidak Mampu 2 Orang</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form class="row" action="/admin/e-surat/surat-ktm-dua" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="row mb-3">
                                            <label for="nomor_surat2" class="col-sm-3 col-form-label">Nomor Surat</label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control" id="nomor_surat2" name="nomor_surat" value="<?php echo e($TemplateNoSurat); ?>" required>
                                            </div>
                                        </div>
                                        <h5 class="modal-title mt-2 mb-3">Data Orang ke-1</h5>
                                        <div class="row mb-3">
                                            <label for="nik_satu" class="col-sm-3 col-form-label">NIK</label>
                                            <div class="col-sm-9">
                                                <input type="number" name="nik" class="form-control" id="nik_satu" value="<?php echo e(old('nik')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="nama_satu" class="col-sm-3 col-form-label">Nama</label>
                                            <div class="col-sm-9">
                                                <input type="text" name="nama" class="form-control" id="nama_satu" value="<?php echo e(old('nama')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="tempat_lahir_satu" class="col-sm-4 col-form-label">Tempat / Tanggal Lahir</label>
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control" id="tempat_lahir_satu" name="tempat_lahir" value="<?php echo e(old('tempat_lahir')); ?>" required>
                                            </div>
                                            <label for="tanggal_lahir_satu" class="col-sm-1 col-form-label text-center">/</label>
                                            <div class="col-sm-3">
                                                <input type="date" class="form-control" id="tanggal_lahir_satu" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="agama_satu" class="col-sm-3 col-form-label">Agama</label>
                                            <div class="col-sm-9">
                                                <select id="agama_satu" name="agama" class="form-select" required>
                                                    <option value="" <?php if(old('agama')=='' ): ?> selected <?php endif; ?>>Pilih Agama ...</option>
                                                    <option value="Islam" <?php if(old('agama')=='Islam' ): ?> selected <?php endif; ?>>Islam</option>
                                                    <option value="Kristen Protestan" <?php if(old('agama')=='Kristen Protestan' ): ?> selected <?php endif; ?>>Kristen Protestan</option>
                                                    <option value="Kristen Katolik" <?php if(old('agama')=='Kristen Katolik' ): ?> selected <?php endif; ?>>Kristen Katolik</option>
                                                    <option value="Hindu" <?php if(old('agama')=='Hindu' ): ?> selected <?php endif; ?>>Hindu</option>
                                                    <option value="Buddha" <?php if(old('agama')=='Buddha' ): ?> selected <?php endif; ?>>Buddha</option>
                                                    <option value="Konghucu" <?php if(old('agama')=='Konghucu' ): ?> selected <?php endif; ?>>Konghucu</option>
                                                    <option value="Lainnya" <?php if(old('agama')=='Lainnya' ): ?> selected <?php endif; ?>>Lainnya</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="pekerjaan_satu" class="col-sm-3 col-form-label">Pekerjaan</label>
                                            <div class="col-sm-9">
                                                <input type="text" name="pekerjaan" class="form-control" id="pekerjaan_satu" value="<?php echo e(old('pekerjaan')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="alamat_satu" class="col-sm-3 col-form-label">Alamat</label>
                                            <div class="col-sm-9">
                                                <input type="text" name="alamat" class="form-control" id="alamat_satu" value="<?php echo e(old('alamat')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="hubungan" class="col-sm-3 col-form-label">Hubungan</label>
                                            <div class="col-sm-9">
                                                <select id="hubungan" name="hubungan" class="form-select" required>
                                                    <option value="" <?php if(old('hubungan')=='' ): ?> selected <?php endif; ?>>Pilih Hubungan ...</option>
                                                    <option value="Orang Tua / Wali" <?php if(old('hubungan')=='Orang Tua / Wali' ): ?> selected <?php endif; ?>>Orang Tua / Wali</option>
                                                    <option value="Suami" <?php if(old('hubungan')=='Suami' ): ?> selected <?php endif; ?>>Suami</option>
                                                    <option value="Istri" <?php if(old('hubungan')=='Istri' ): ?> selected <?php endif; ?>>Istri</option>
                                                </select>
                                            </div>
                                        </div>
                                        <h5 class="modal-title mt-2 mb-3">Data Orang ke-2</h5>
                                        <div class="row mb-3">
                                            <label for="nik_dua" class="col-sm-3 col-form-label">NIK</label>
                                            <div class="col-sm-9">
                                                <input type="text" name="nik_dua" class="form-control" id="nik_dua" value="<?php echo e(old('nik_dua')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="nama_dua" class="col-sm-3 col-form-label">Nama</label>
                                            <div class="col-sm-9">
                                                <input type="text" name="nama_dua" class="form-control" id="nama_dua" value="<?php echo e(old('nama_dua')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="tempat_lahir_dua" class="col-sm-4 col-form-label">Tempat / Tanggal Lahir</label>
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control" id="tempat_lahir_dua" name="tempat_lahir_dua" value="<?php echo e(old('tempat_lahir_dua')); ?>" required>
                                            </div>
                                            <label for="tanggal_lahir_dua" class="col-sm-1 col-form-label text-center">/</label>
                                            <div class="col-sm-3">
                                                <input type="date" class="form-control" id="tanggal_lahir_dua" name="tanggal_lahir_dua" value="<?php echo e(old('tanggal_lahir_dua')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="agama_dua" class="col-sm-3 col-form-label">Agama</label>
                                            <div class="col-sm-9">
                                                <select id="agama_dua" name="agama_dua" class="form-select" required>
                                                    <option value="" <?php if(old('agama_dua')=='' ): ?> selected <?php endif; ?>>Pilih Agama ...</option>
                                                    <option value="Islam" <?php if(old('agama_dua')=='Islam' ): ?> selected <?php endif; ?>>Islam</option>
                                                    <option value="Kristen Protestan" <?php if(old('agama_dua')=='Kristen Protestan' ): ?> selected <?php endif; ?>>Kristen Protestan</option>
                                                    <option value="Kristen Katolik" <?php if(old('agama_dua')=='Kristen Katolik' ): ?> selected <?php endif; ?>>Kristen Katolik</option>
                                                    <option value="Hindu" <?php if(old('agama_dua')=='Hindu' ): ?> selected <?php endif; ?>>Hindu</option>
                                                    <option value="Buddha" <?php if(old('agama_dua')=='Buddha' ): ?> selected <?php endif; ?>>Buddha</option>
                                                    <option value="Konghucu" <?php if(old('agama_dua')=='Konghucu' ): ?> selected <?php endif; ?>>Konghucu</option>
                                                    <option value="Lainnya" <?php if(old('agama_dua')=='Lainnya' ): ?> selected <?php endif; ?>>Lainnya</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="pekerjaan_dua" class="col-sm-3 col-form-label">Pekerjaan</label>
                                            <div class="col-sm-9">
                                                <input type="text" name="pekerjaan_dua" class="form-control" id="pekerjaan_dua" value="<?php echo e(old('pekerjaan_dua')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="alamat_dua" class="col-sm-3 col-form-label">Alamat</label>
                                            <div class="col-sm-9">
                                                <input type="text" name="alamat_dua" class="form-control" id="alamat_dua" value="<?php echo e(old('alamat_dua')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="deskripsi2" class="col-sm-3 col-form-label">Deskripsi</label>
                                            <div class="col-sm-9">
                                                <textarea type="text" name="deskripsi" class="form-control" id="deskripsi2" rows="3" required>Bahwa bersangkutan tersebut adalah benar dari keluarga kurang mampu.</textarea>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="tanda_tangan" class="col-sm-3 col-form-label">Tanda Tangan</label>
                                            <div class="col-sm-9">
                                                <select id="tanda_tangan" name="tanda_tangan[]" class="form-select" required>
                                                    <option value="" disabled selected>Pilih Pejabat yang Bertanda tangan</option>
                                                    <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value['id'].'/'.$value['nama'].'/'.$value['jabatan']); ?>"><?php echo e($value['nama'] . ' ( ' . $value['jabatan'] . ' )'); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <label for="mengetahui" class="col col-form-label">Pejabat Yang mengetahui</label>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-4 mb-3">
                                                <select id="mengetahui[]" name="mengetahui[]" class="form-select" required>
                                                    <option value="" disabled selected>Pilih Pejabat yang Mengetahui</option>
                                                    <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value['id'].'/'.$value['nama'].'/'.$value['jabatan']); ?>"><?php echo e($value['nama'] . ' ( ' . $value['jabatan'] . ' )'); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <select id="mengetahui[]" name="mengetahui[]" class="form-select">
                                                    <option value="" selected>Pilih Pejabat yang Mengetahui</option>
                                                    <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value['id'].'/'.$value['nama'].'/'.$value['jabatan']); ?>"><?php echo e($value['nama'] . ' ( ' . $value['jabatan'] . ' )'); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-md-4">
                                                <select id="mengetahui[]" name="mengetahui[]" class="form-select">
                                                    <option value="" selected>Pilih Pejabat yang Mengetahui</option>
                                                    <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value['id'].'/'.$value['nama'].'/'.$value['jabatan']); ?>"><?php echo e($value['nama'] . ' ( ' . $value['jabatan'] . ' )'); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="card-title">Data Surat Keterangan Tidak Mampu</h5>
                    </div>

                    <!-- Table with hoverable rows -->
                    <table class="table table-hover datatable">
                        <thead>
                            <tr>
                                <th scope="col">No.</th>
                                <th scope="col">Nomor Surat</th>
                                <th scope="col">Nama</th>
                                <th scope="col">NIK</th>
                                <th scope="col">Status</th>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit surat', 'lihat surat', 'hapus surat'])): ?>
                                <th scope="col" class="text-center">Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sktm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?>.</th>
                                <td><?php echo e($value->nomor_surat); ?></td>
                                <td><?php echo e($value->nama); ?></td>
                                <td><?php echo e($value->nik); ?></td>
                                <td>
                                    <a data-bs-toggle="modal" data-bs-target="#status_<?php echo e($value->id); ?>" class="btn btn-primary">
                                        <i class="bi bi-clock-history"></i> Lihat
                                    </a>
                                </td>
                                <!-- ini bagian modal badge status verifikasi -->
                                <div class="modal fade" id="status_<?php echo e($value->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg modal-dialog-scrollable">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Status Surat Keterangan Tidak Mampu <?php echo e($value->nomor_surat); ?></h5>
                                                <div class="mx-3"><?php echo $badge_status[$value->status_surat]; ?></div>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="container">
                                                    <?php $__currentLoopData = $value->MengetahuiVerifikasiSurat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $verifikasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="row border-bottom p-3">
                                                        <div class="col-sm-3">
                                                            <?php echo $badge_status[$verifikasi->status]; ?>

                                                            <?php echo e($verifikasi->updated_at); ?>

                                                        </div>
                                                        <div class="col mx-5">
                                                            <?php echo e($verifikasi->nama_user); ?>

                                                            ( <?php echo e($verifikasi->jabatan_user); ?> )
                                                        </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- bagian action -->
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit surat', 'lihat surat', 'hapus surat'])): ?>
                                <td class="text-center d-flex justify-content-evenly">
                                    <?php if($value->jenis_surat == 'Surat Keterangan Tidak Mampu 1'): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lihat surat')): ?>
                                    <a class="btn <?php echo e(($value->status_surat == '2')?'btn-success':'btn-secondary'); ?>" type="submit" target="blank" href="/admin/e-surat/surat-ktm-satu/<?php echo e($value->id); ?>/view"><i class="fa-solid fa-print"></i></a>
                                    <!-- Button trigger modal -->
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit surat')): ?>
                                    <a class="btn btn-warning" type="submit" data-bs-toggle="modal" data-bs-target="#Modal-Edit-SKTM-Satu-<?php echo e($value->id); ?>" href="/admin/e-surat/surat-ktm-satu/<?php echo e($value->id); ?>/editSatu"><i class="fa-solid fa-pen-to-square"></i></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('hapus surat')): ?>
                                    <a data-bs-toggle="modal" data-bs-target="#kearsip_<?php echo e($value->id); ?>">
                                        <?php if($value->status_surat == '2'): ?>
                                        <button class="btn btn-success">
                                            <i class="fa-solid fa-circle-up"></i>
                                            <?php else: ?>
                                            <button class="btn btn-danger">
                                                <i class="fa-solid fa-circle-up"></i>
                                                <?php endif; ?>
                                            </button>
                                    </a>
                                    <!-- modal hapus atau delete -->
                                    <div class="modal fade" id="kearsip_<?php echo e($value->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg modal-dialog-scrollable">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Surat Keterangan Tidak Mampu <?php echo e($value->nomor_surat); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="container">
                                                        <p>Apakah Anda yakin untuk mengarsipkan surat dengan nomor <?php echo e($value->nomor_surat); ?></p>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <form action="/admin/e-surat/surat-ktm-satu/<?php echo e($value->id); ?>/<?php echo e($value->status_surat); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn <?php echo e(($value->status_surat == '2')?'btn-success':'btn-danger'); ?>">Arsipkan</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>

                                    <?php else: ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lihat surat')): ?>
                                    <a class="btn <?php echo e(($value->status_surat == '2')?'btn-success':'btn-secondary'); ?>" type="submit" target="blank" href="/admin/e-surat/surat-ktm-dua/<?php echo e($value->id); ?>/view"><i class="fa-solid fa-print"></i></a>
                                    <!-- Button trigger modal -->
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit surat')): ?>
                                    <a class="btn btn-warning" type="submit" data-bs-toggle="modal" data-bs-target="#Modal-Edit-SKTM-Dua-<?php echo e($value->id); ?>" href="/admin/e-surat/surat-ktm-dua/<?php echo e($value->id); ?>/editDua"><i class="fa-solid fa-pen-to-square"></i></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('hapus surat')): ?>
                                    <a data-bs-toggle="modal" data-bs-target="#kearsip_<?php echo e($value->id); ?>">
                                        <?php if($value->status_surat == '2'): ?>
                                        <button class="btn btn-success">
                                            <i class="bi bi-check-lg"></i>
                                            <?php else: ?>
                                            <button class="btn btn-danger">
                                                <i class="fa-regular fa-trash-can"></i>
                                                <?php endif; ?>
                                            </button>
                                    </a>
                                    <!-- modal hapus atau delete -->
                                    <div class="modal fade" id="kearsip_<?php echo e($value->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg modal-dialog-scrollable">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Surat Keterangan Tidak Mampu <?php echo e($value->nomor_surat); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="container">
                                                        <p>Apakah Anda yakin untuk mengarsipkan surat dengan nomor <?php echo e($value->nomor_surat); ?></p>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <form action="/admin/e-surat/surat-ktm-dua/<?php echo e($value->id); ?>/<?php echo e($value->status_surat); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn <?php echo e(($value->status_surat == '2')?'btn-success':'btn-danger'); ?>">Arsipkan</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <?php endif; ?>
                            </tr>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit surat')): ?>
                            <!-- Modal Edit SKTM Satu Orang -->
                            <div class="modal fade" id="Modal-Edit-SKTM-Satu-<?php echo e($value->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="Modal-Edit-SKTM-Satu-Label" aria-hidden="true">
                                <div class="modal-dialog modal-lg modal-dialog-scrollable">
                                    <div class="modal-content">
                                        <form action="/admin/e-surat/surat-ktm-satu/<?php echo e($value->id); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('put'); ?>
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="Modal-Edit-SKTM-Satu-Label">Edit Data Surat Keterangan Tidak Mampu 1 Orang <?php echo e($value->nomor_surat); ?></h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row mb-3">
                                                    <label for="nomor_surat3" class="col-sm-3 col-form-label">Nomor Surat</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="nomor_surat3" name="nomor_surat" value="<?php echo e($value->nomor_surat); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="nama3" class="col-sm-3 col-form-label">Nama</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" name="nama" class="form-control" id="nama3" value="<?php echo e($value->nama); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="nik3" class="col-sm-3 col-form-label">NIK</label>
                                                    <div class="col-sm-9">
                                                        <input type="number" name="nik" class="form-control" id="nik3" value="<?php echo e($value->nik); ?>" min="16" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="jenis_kelamin3" class="col-sm-3 col-form-label">Jenis Kelamin</label>
                                                    <div class="col-sm-9">
                                                        <select id="jenis_kelamin3" name="jenis_kelamin" class="form-select" required>
                                                            <option value="">Pilih Jenis Kelamin ...</option>
                                                            <option value="Laki-laki" <?php echo e(($value->jenis_kelamin == "Laki-laki") ? 'selected' : ''); ?>>Laki-laki</option>
                                                            <option value="Perempuan" <?php echo e(($value->jenis_kelamin == "Perempuan") ? 'selected' : ''); ?>>Perempuan</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="tempat_lahir3" class="col-sm-4 col-form-label">Tempat / Tanggal Lahir</label>
                                                    <div class="col-sm-4">
                                                        <input type="text" class="form-control" id="tempat_lahir3" name="tempat_lahir" value="<?php echo e($value->tempat_lahir); ?>" required>
                                                    </div>
                                                    <label for="tanggal_lahir3" class="col-sm-1 col-form-label text-center">/</label>
                                                    <div class="col-sm-3">
                                                        <input type="date" class="form-control" id="tanggal_lahir3" name="tanggal_lahir" value="<?php echo e($value->tanggal_lahir); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="agama3" class="col-sm-3 col-form-label">Agama</label>
                                                    <div class="col-sm-9">
                                                        <select id="agama3" name="agama" class="form-select" required>
                                                            <option value="">Pilih Agama ...</option>
                                                            <option value="Islam" <?php echo e(($value->agama == "Islam") ? 'selected' : ''); ?>>Islam</option>
                                                            <option value="Kristen Protestan" <?php echo e(($value->agama == "Kristen Protestan") ? 'selected' : ''); ?>>Kristen Protestan</option>
                                                            <option value="Kristen Katolik" <?php echo e(($value->agama == "Kristen Katolik") ? 'selected' : ''); ?>>Kristen Katolik</option>
                                                            <option value="Hindu" <?php echo e(($value->agama == "Hindu") ? 'selected' : ''); ?>>Hindu</option>
                                                            <option value="Buddha" <?php echo e(($value->agama == "Buddha") ? 'selected' : ''); ?>>Buddha</option>
                                                            <option value="Konghucu" <?php echo e(($value->agama == "Konghucu") ? 'selected' : ''); ?>>Konghucu</option>
                                                            <option value="Lainnya" <?php echo e(($value->agama == "Lainnya") ? 'selected' : ''); ?>>Lainnya</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="status_perkawinan3" class="col-sm-3 col-form-label">Status Perkawinan</label>
                                                    <div class="col-sm-9">
                                                        <select id="status_perkawinan3" name="status_perkawinan" class="form-select" required>
                                                            <option value="">Pilih Status Perkawinan ...</option>
                                                            <option value="Belum Menikah" <?php echo e(($value->status_perkawinan == "Belum Menikah") ? 'selected' : ''); ?>>Belum Menikah</option>
                                                            <option value="Sudah Menikah" <?php echo e(($value->status_perkawinan == "Sudah Menikah") ? 'selected' : ''); ?>>Sudah Menikah</option>
                                                            <option value="Janda" <?php echo e(($value->status_perkawinan == "Janda") ? 'selected' : ''); ?>>Janda</option>
                                                            <option value="Duda" <?php echo e(($value->status_perkawinan == "Duda") ? 'selected' : ''); ?>>Duda</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="pekerjaan3" class="col-sm-3 col-form-label">Pekerjaan</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" name="pekerjaan" class="form-control" id="pekerjaan3" value="<?php echo e($value->pekerjaan); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="alamat3" class="col-sm-3 col-form-label">Alamat</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" name="alamat" class="form-control" id="alamat3" value="<?php echo e($value->alamat); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="deskripsi3" class="col-sm-3 col-form-label">Deskripsi</label>
                                                    <div class="col-sm-9">
                                                        <textarea type="text" name="deskripsi" class="form-control" id="deskripsi3" rows="3" required><?php echo e($value->deskripsi); ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="tanda_tangan" class="col-sm-3 col-form-label">Tanda Tangan</label>
                                                    <div class="col-sm-9">
                                                        <select id="tanda_tangan" name="tanda_tangan[]" class="form-select" required>
                                                            <option value="" disabled selected>Pilih Pejabat yang Bertanda tangan</option>
                                                            <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($value->tandatangan[0]->id.'/'.$jabat['id'].'/'.$jabat['nama'].'/'.$jabat['jabatan']); ?>" <?php echo e(($value->tandatangan[0]->id_user == $jabat['id'])?'selected':''); ?>><?php echo e($jabat['nama'] . ' ( ' . $jabat['jabatan'] . ' )'); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <label for="mengetahui" class="col col-form-label">Pejabat Yang mengetahui</label>
                                                </div>
                                                <div class="row">
                                                    <?php $__currentLoopData = $value->MengetahuiVerifikasiSurat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $verifikasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-md-4">
                                                        <select id="mengetahui[]" name="mengetahui[]" class="form-select">
                                                            <option value="" disabled selected>Pilih Pejabat yang Bertanda tangan</option>
                                                            <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($verifikasi->id.'/'.$jabat['id'].'/'.$jabat['nama'].'/'.$jabat['jabatan']); ?>" <?php echo e(($verifikasi->id_user == $jabat['id'])?'selected':''); ?>><?php echo e($jabat['nama'] . ' ( ' . $jabat['jabatan'] . ' )'); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(count($value->MengetahuiVerifikasiSurat) < 3): ?> <?php $__currentLoopData = range(1, 3 - count($value->MengetahuiVerifikasiSurat)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-md-4">
                                                            <select id="mengetahui[]" name="mengetahui[]" class="form-select">
                                                                <option value="" disabled selected>Pilih Pejabat yang Bertanda tangan</option>
                                                                <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e('-/'.$jabat['id'].'/'.$jabat['nama'].'/'.$jabat['jabatan']); ?>"><?php echo e($jabat['nama'] . ' ( ' . $jabat['jabatan'] . ' )'); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Simpan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Modal Edit SKTM Dua Orang -->
                            <div class="modal fade" id="Modal-Edit-SKTM-Dua-<?php echo e($value->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="Modal-Edit-SKTM-Dua-Label" aria-hidden="true">
                                <div class="modal-dialog modal-lg modal-dialog-scrollable">
                                    <div class="modal-content">
                                        <form action="/admin/e-surat/surat-ktm-dua/<?php echo e($value->id); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('put'); ?>
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="Modal-Edit-SKTM-Dua-Label">Edit Data Surat Keterangan Tidak Mampu 2 Orang <?php echo e($value->nomor_surat); ?></h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row mb-3">
                                                    <label for="nomor_surat5" class="col-sm-3 col-form-label">Nomor Surat</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="nomor_surat5" name="nomor_surat" value="<?php echo e($value->nomor_surat); ?>" required>
                                                    </div>
                                                </div>
                                                <h5 class="modal-title mt-2 mb-3">Data Orang ke-1</h5>
                                                <div class="row mb-3">
                                                    <label for="nama4" class="col-sm-3 col-form-label">Nama</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" name="nama" class="form-control" id="nama4" value="<?php echo e($value->nama); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="nik4" class="col-sm-3 col-form-label">NIK</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" name="nik" class="form-control" id="nik4" value="<?php echo e($value->nik); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="tempat_lahir4" class="col-sm-4 col-form-label">Tempat / Tanggal Lahir</label>
                                                    <div class="col-sm-4">
                                                        <input type="text" class="form-control" id="tempat_lahir4" name="tempat_lahir" value="<?php echo e($value->tempat_lahir); ?>" required>
                                                    </div>
                                                    <label for="tanggal_lahir4" class="col-sm-1 col-form-label text-center">/</label>
                                                    <div class="col-sm-3">
                                                        <input type="date" class="form-control" id="tanggal_lahir4" name="tanggal_lahir" value="<?php echo e($value->tanggal_lahir); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="agama4" class="col-sm-3 col-form-label">Agama</label>
                                                    <div class="col-sm-9">
                                                        <select id="agama4" name="agama" class="form-select" required>
                                                            <option value="">Pilih Agama ...</option>
                                                            <option value="Islam" <?php echo e(($value->agama == "Islam") ? 'selected' : ''); ?>>Islam</option>
                                                            <option value="Kristen Protestan" <?php echo e(($value->agama == "Kristen Protestan") ? 'selected' : ''); ?>>Kristen Protestan</option>
                                                            <option value="Kristen Katolik" <?php echo e(($value->agama == "Kristen Katolik") ? 'selected' : ''); ?>>Kristen Katolik</option>
                                                            <option value="Hindu" <?php echo e(($value->agama == "Hindu") ? 'selected' : ''); ?>>Hindu</option>
                                                            <option value="Buddha" <?php echo e(($value->agama == "Buddha") ? 'selected' : ''); ?>>Buddha</option>
                                                            <option value="Konghucu" <?php echo e(($value->agama == "Konghucu") ? 'selected' : ''); ?>>Konghucu</option>
                                                            <option value="Lainnya" <?php echo e(($value->agama == "Lainnya") ? 'selected' : ''); ?>>Lainnya</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="pekerjaan4" class="col-sm-3 col-form-label">Pekerjaan</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" name="pekerjaan" class="form-control" id="pekerjaan4" value="<?php echo e($value->pekerjaan); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="alamat4" class="col-sm-3 col-form-label">Alamat</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" name="alamat" class="form-control" id="alamat4" value="<?php echo e($value->alamat); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="hubungan4" class="col-sm-3 col-form-label">Hubungan</label>
                                                    <div class="col-sm-9">
                                                        <select id="hubungan4" name="hubungan" class="form-select" required>
                                                            <option value="">Pilih Status Perkawinan ...</option>
                                                            <option value="Orang Tua / Wali" <?php echo e(($value->hubungan == "Orang Tua / Wali") ? 'selected' : ''); ?>>Orang Tua / Wali</option>
                                                            <option value="Suami" <?php echo e(($value->hubungan == "Suami") ? 'selected' : ''); ?>>Suami</option>
                                                            <option value="Istri" <?php echo e(($value->hubungan == "Istri") ? 'selected' : ''); ?>>Istri</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <h5 class="modal-title mt-2 mb-3">Data Orang ke-2</h5>
                                                <div class="row mb-3">
                                                    <label for="nama_dua4" class="col-sm-3 col-form-label">Nama</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" name="nama_dua" class="form-control" id="nama_dua4" value="<?php echo e($value->nama_dua); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="nik_dua4" class="col-sm-3 col-form-label">NIK</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" name="nik_dua" class="form-control" id="nik_dua4" value="<?php echo e($value->nik_dua); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="tempat_lahir_dua4" class="col-sm-4 col-form-label">Tempat / Tanggal Lahir</label>
                                                    <div class="col-sm-4">
                                                        <input type="text" class="form-control" id="tempat_lahir_dua4" name="tempat_lahir_dua" value="<?php echo e($value->tempat_lahir_dua); ?>" required>
                                                    </div>
                                                    <label for="tanggal_lahir_dua4" class="col-sm-1 col-form-label text-center">/</label>
                                                    <div class="col-sm-3">
                                                        <input type="date" class="form-control" id="tanggal_lahir_dua4" name="tanggal_lahir_dua" value="<?php echo e($value->tanggal_lahir_dua); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="agama_dua4" class="col-sm-3 col-form-label">Agama</label>
                                                    <div class="col-sm-9">
                                                        <select id="agama_dua4" name="agama_dua" class="form-select" required>
                                                            <option value="">Pilih Agama ...</option>
                                                            <option value="Islam" <?php echo e(($value->agama_dua == "Islam") ? 'selected' : ''); ?>>Islam</option>
                                                            <option value="Kristen Protestan" <?php echo e(($value->agama_dua == "Kristen Protestan") ? 'selected' : ''); ?>>Kristen Protestan</option>
                                                            <option value="Kristen Katolik" <?php echo e(($value->agama_dua == "Kristen Katolik") ? 'selected' : ''); ?>>Kristen Katolik</option>
                                                            <option value="Hindu" <?php echo e(($value->agama_dua == "Hindu") ? 'selected' : ''); ?>>Hindu</option>
                                                            <option value="Buddha" <?php echo e(($value->agama_dua == "Buddha") ? 'selected' : ''); ?>>Buddha</option>
                                                            <option value="Konghucu" <?php echo e(($value->agama_dua == "Konghucu") ? 'selected' : ''); ?>>Konghucu</option>
                                                            <option value="Lainnya" <?php echo e(($value->agama_dua == "Lainnya") ? 'selected' : ''); ?>>Lainnya</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="pekerjaan_dua4" class="col-sm-3 col-form-label">Pekerjaan</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" name="pekerjaan_dua" class="form-control" id="pekerjaan_dua4" value="<?php echo e($value->pekerjaan_dua); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="alamat_dua4" class="col-sm-3 col-form-label">Alamat</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" name="alamat_dua" class="form-control" id="alamat_dua4" value="<?php echo e($value->alamat_dua); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="deskripsi4" class="col-sm-3 col-form-label">Deskripsi</label>
                                                    <div class="col-sm-9">
                                                        <textarea type="text" name="deskripsi" class="form-control" id="deskripsi4" rows="3" required><?php echo e($value->deskripsi); ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <label for="tanda_tangan" class="col-sm-3 col-form-label">Tanda Tangan</label>
                                                    <div class="col-sm-9">
                                                        <select id="tanda_tangan" name="tanda_tangan[]" class="form-select" required>
                                                            <option value="" disabled selected>Pilih Pejabat yang Bertanda tangan</option>
                                                            <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($value->tandatangan[0]->id.'/'.$jabat['id'].'/'.$jabat['nama'].'/'.$jabat['jabatan']); ?>" <?php echo e(($value->tandatangan[0]->id_user == $jabat['id'])?'selected':''); ?>><?php echo e($jabat['nama'] . ' ( ' . $jabat['jabatan'] . ' )'); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <label for="mengetahui" class="col col-form-label">Pejabat Yang mengetahui</label>
                                                </div>
                                                <div class="row">
                                                    <?php $__currentLoopData = $value->MengetahuiVerifikasiSurat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $verifikasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-md-4">
                                                        <select id="mengetahui[]" name="mengetahui[]" class="form-select">
                                                            <option value="" disabled selected>Pilih Pejabat yang Bertanda tangan</option>
                                                            <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($verifikasi->id.'/'.$jabat['id'].'/'.$jabat['nama'].'/'.$jabat['jabatan']); ?>" <?php echo e(($verifikasi->id_user == $jabat['id'])?'selected':''); ?>><?php echo e($jabat['nama'] . ' ( ' . $jabat['jabatan'] . ' )'); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(count($value->MengetahuiVerifikasiSurat) < 3): ?> <?php $__currentLoopData = range(1, 3 - count($value->MengetahuiVerifikasiSurat)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-md-4">
                                                            <select id="mengetahui[]" name="mengetahui[]" class="form-select">
                                                                <option value="" disabled selected>Pilih Pejabat yang Bertanda tangan</option>
                                                                <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e('-/'.$jabat['id'].'/'.$jabat['nama'].'/'.$jabat['jabatan']); ?>"><?php echo e($jabat['nama'] . ' ( ' . $jabat['jabatan'] . ' )'); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Simpan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <!-- End Table with hoverable rows -->

                </div>
            </div>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bo.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_sentolo\sentolo_gab_si\resources\views/bo/page/surat/keluar/surat-ktm.blade.php ENDPATH**/ ?>