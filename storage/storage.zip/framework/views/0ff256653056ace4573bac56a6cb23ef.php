<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
            <a class="nav-link <?php echo e(($title == "Dashboard") ? '' : 'collapsed'); ?>" href="/admin/e-surat/dashboard">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>
        </li><!-- End Dashboard Nav -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Surat Keluar')): ?>
        <li class="nav-item">
            <a class="nav-link <?php echo e(($dropdown1 == "Surat Keluar") ? '' : 'collapsed'); ?>" data-bs-target="#surat-nav" data-bs-toggle="collapse" href="#">
                <i class="fa-regular fa-envelope"></i><span>Surat Keluar</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>

            <ul id="surat-nav" class="nav-content collapse <?php echo e(($dropdown1 == "Surat Keluar") ? 'show' : ''); ?>" data-bs-parent="#sidebar-nav">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(($dropdown2 == "Kemasyarakatan") ? '' : 'collapsed'); ?>" data-bs-target="#kemasyarakatan-nav" data-bs-toggle="collapse" href="#">
                        <span>Kemasyarakatan</span><i class="bi bi-chevron-down ms-auto dropdown-dua"></i>
                    </a>
                    <ul id="kemasyarakatan-nav" class="nav-content collapse <?php echo e(($dropdown2 == "Kemasyarakatan" && $dropdown1 == "Surat Keluar") ? 'show' : ''); ?>" data-bs-parent="#surat-nav">
                        <li>
                            <a href="/admin/e-surat/surat-ktm" class="<?php echo e(($title == "Surat Keterangan Tidak Mampu") ? 'active' : ''); ?>">
                                <i class="bi bi-circle"></i><span>Keterangan Tidak Mampu</span>
                            </a>
                        </li>
                        <li>
                            <a href="/admin/e-surat/surat-pbm" class="<?php echo e(($title == "Surat Pernyataan Belum Menikah") ? 'active' : ''); ?>">
                                <i class="bi bi-circle"></i><span>Pernyataan Belum Menikah</span>
                            </a>
                        </li>
                        <li>
                            <a href="/admin/e-surat/surat-kbm" class="<?php echo e(($title == "Surat Keterangan Belum Menikah") ? 'active' : ''); ?>">
                                <i class="bi bi-circle"></i><span>Keterangan  Belum Menikah</span>
                            </a>
                        </li>
                        <li>
                            <a href="/admin/e-surat/surat-pn" class="<?php echo e(($title == "Surat Pengantar Nikah") ? 'active' : ''); ?>">
                                <i class="bi bi-circle"></i><span>Pengantar Nikah</span>
                            </a>
                        </li>
                        <li>
                            <a href="/admin/e-surat/surat-pektp" class="<?php echo e(($title == "Surat Pengantar E-KTP") ? 'active' : ''); ?>">
                                <i class="bi bi-circle"></i><span>Pengantar E-KTP</span>
                            </a>
                        </li>
                        <li>
                            <a href="/admin/e-surat/surat-pskck" class="<?php echo e(($title == "Surat Pengantar SKCK") ? 'active' : ''); ?>">
                                <i class="bi bi-circle"></i><span>Pengantar SKCK</span>
                            </a>
                        </li>
                        <li>
                            <a href="/admin/e-surat/surat-belum-bekerja" class="<?php echo e(($title == "Surat Pernyataan Belum Bekerja") ? 'active' : ''); ?>">
                                <i class="bi bi-circle"></i><span>Pernyataan Belum Bekerja</span>
                            </a>
                        </li>
                        <li>
                            <a href="/admin/e-surat/surat-ket-hasil" class="<?php echo e(($title == "Surat Keterangan Penghasilan") ? 'active' : ''); ?>">
                                <i class="bi bi-circle"></i><span>Keterangan Penghasilan</span>
                            </a>
                        </li>
                        <li>
                            <a href="/admin/e-surat/surat-cstm" class="<?php echo e(($title == "Surat Custom") ? 'active' : ''); ?>">
                                <i class="bi bi-circle"></i><span>Surat Custom</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(($dropdown2 == "Pemerintahan") ? '' : 'collapsed'); ?>" data-bs-target="#pemerintahan-nav" data-bs-toggle="collapse" href="#">
                        <span>Pemerintahan</span><i class="bi bi-chevron-down ms-auto dropdown-dua"></i>
                    </a>
                    <ul id="pemerintahan-nav" class="nav-content collapse <?php echo e(($dropdown2 == "Pemerintahan" && $dropdown1 == "Surat Keluar") ? 'show' : ''); ?>" data-bs-parent="#surat-nav">
                        <li>
                            <a href="/admin/e-surat/surat-kdomisili" class="<?php echo e(($title == "Surat Keterangan Domisili") ? 'active' : ''); ?>">
                                <i class="bi bi-circle"></i><span>Keterangan Domisili</span>
                            </a>
                        </li>
                        <li>
                            <a href="/admin/e-surat/surat-kkelahiran" class="<?php echo e(($title == "Surat Keterangan Kelahiran") ? 'active' : ''); ?>">
                                <i class="bi bi-circle"></i><span>Keterangan Kelahiran</span>
                            </a>
                        </li>
                        <li>
                        <a href="/admin/e-surat/surat-kduda" class="<?php echo e(($title == "Surat Keterangan Duda / Janda") ? 'active' : ''); ?>">
                            <i class="bi bi-circle"></i><span>Keterangan Duda / Janda</span>
                        </a>
                        </li>
                        <li>
                            <a href="/admin/e-surat/surat-ktbekerja" class="<?php echo e(($title == "Surat Keterangan Tidak Bekerja") ? 'active' : ''); ?>">
                                <i class="bi bi-circle"></i><span>Keterangan Tidak Bekerja</span>
                            </a>
                        </li>
                        <li>
                            <a href="/admin/e-surat/surat-kkematian" class="<?php echo e(($title == "Surat Keterangan Kematian") ? 'active' : ''); ?>">
                                <i class="bi bi-circle"></i><span>Keterangan Kematian</span>
                            </a>
                        </li>
                        <li>
                            <a href="/admin/e-surat/surat-pk" class="<?php echo e(($title == "Surat Pengantar Kependudukan") ? 'active' : ''); ?>">
                                <i class="bi bi-circle"></i><span>Pengantar Kependudukan</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li><!-- End Nav -->
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Surat Masuk')): ?>
        <li class="nav-item">
            <a class="nav-link <?php echo e(($title == "Surat Masuk") ? '' : 'collapsed'); ?>" href="/admin/e-surat/surat-masuk">
                <i class="fa-regular fa-envelope-open"></i>
                <span>Surat Masuk</span>
            </a>
        </li><!-- End Surat Masuk Nav -->
        <?php endif; ?>
        <li class="nav-item">
            <a class="nav-link <?php echo e(($title == "Verifikasi Surat Keluar") ? '' : 'collapsed'); ?>" href="/admin/e-surat/validasi">
                <i class="bi bi-file-earmark-check"></i>
                <span>Verifikasi Surat</span>
            </a>
        </li><!-- End Validasi Nav -->
        <li class="nav-item">
            <a class="nav-link <?php echo e(($title == "Disposisi Surat Masuk") ? '' : 'collapsed'); ?>" href="/admin/e-surat/disposisi">
                <i class="bi bi-mailbox"></i>
                <span>Disposisi Surat</span>
            </a>
        </li><!-- End Disposisi Nav -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Arsip Surat')): ?>
        <li class="nav-item">
            <a class="nav-link <?php echo e(($title == "Arsip Desa") ? '' : 'collapsed'); ?>" href="/admin/e-surat/arsip">
                <i class="bi bi-archive"></i>
                <span>Arsip Surat</span>
            </a>
        </li><!-- End Validasi Nav -->
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Arsip Dihapus')): ?>
        <li class="nav-item">
            <a class="nav-link <?php echo e(($title == 'Arsip Desa Telah Dihapus') ? '' : 'collapsed'); ?>" href="/admin/e-surat/arsip_dihapus">
                <i class="bi bi-archive-fill"></i>
                <span>Arsip Sudah Dihapus</span>
            </a>
        </li><!-- End Validasi Nav -->
        <?php endif; ?>
    </ul>

</aside>
<?php /**PATH D:\project_sentolo\sentolo_gab_si\resources\views/bo/partial/sidebar_surat.blade.php ENDPATH**/ ?>