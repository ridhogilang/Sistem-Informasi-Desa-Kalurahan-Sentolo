<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1><?php echo e($title); ?></h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/admin/e-surat/dashboard">Home</a></li>
                <li class="breadcrumb-item active"><?php echo e($title); ?></li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section">
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="card-title">Data <?php echo e($title); ?></h5>
                        </div>

                        <!-- Table with hoverable rows -->
                        <table class="table table-hover datatable">
                            <thead>
                                <tr>
                                    <th scope="col" class="text-center">No.</th>
                                    <th scope="col" class="text-center">Nomor Surat</th>
                                    <th scope="col" class="text-center">Tanggal Kegiatan</th>
                                    <th scope="col" class="text-center">Riwayat</th>
                                    <th scope="col" class="text-center">Isi Surat</th>
                                    <th scope="col" class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($value->suratMasuk->nomor_surat); ?></td>
                                        <td><?php echo e(date("d F Y", strtotime($value->suratMasuk->tanggal_kegiatan))); ?></td>
                                        <td class="text-center">
                                            <a data-bs-toggle="modal" data-bs-target="#status_<?php echo e($value->id); ?>" class="btn btn-primary">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        </td>
                                        <!-- ini bagian modal badge status verifikasi -->
                                        <div class="modal fade" id="status_<?php echo e($value->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg modal-dialog-scrollable">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Riwayat Surat <?php echo e($value->suratMasuk->nomor_surat); ?></h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="container">
                                                            <?php
                                                                $pamongDps[$value->id][] = '-';
                                                            ?>
                                                            <?php $__currentLoopData = $value->detilDisposisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detildis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="row border-bottom p-3">
                                                                <div class="col">
                                                                    Diterima : <?php echo e($detildis->tgl_diterima_dari_disposisi); ?><br>
                                                                    <?php if(auth()->user()->id == $detildis->id_user): ?>
                                                                        Anda <br>
                                                                    <?php elseif($detildis->id_user == 'PU'): ?>
                                                                        ( <?php echo e($detildis->jabatan_user); ?> )<br>
                                                                    <?php else: ?>
                                                                        <?php echo e($detildis->pamongDPSS->nama); ?> ( <?php echo e($detildis->jabatan_user); ?> )<br>
                                                                    <?php endif; ?>
                                                                    <!-- memilih status -->
                                                                    <?php if($detildis->id_user == 'PU'): ?>
                                                                        Surat Dianalisis ulang oleh Pelayanan Umum
                                                                    <?php elseif($detildis->status_disposisi == '1' || $detildis->status_disposisi == '4'): ?>
                                                                        <?php echo ($detildis->jenis_disposisi == 'PLK')?$badge_disposisi_status['4']:''; ?>


                                                                        <?php echo $badge_disposisi_status[$detildis->status_disposisi]; ?>


                                                                    <?php else: ?>
                                                                    Tindakan : <?php echo e($detildis->tgl_dilanjutkan_ke_disposisi); ?><br>
                                                                        <?php echo ($detildis->jenis_disposisi == 'PLK')?$badge_disposisi_status['4']:''; ?>

                                                                        <?php echo $badge_disposisi_status[$detildis->status_disposisi]; ?> <?php echo e($detildis->catatan); ?>

                                                                    <?php endif; ?>

                                                                </div>
                                                            </div>
                                                            <?php
                                                                if (!in_array($detildis->id_user, $pamongDps[$value->id])) {
                                                                    if ($detildis->status_disposisi != '3') {
                                                                        $pamongDps[$value->id][] = $detildis->id_user;
                                                                    }
                                                                } else {
                                                                    $index = array_search($detildis->id_user, $pamongDps[$value->id]);
                                                                    if ($detildis->status_disposisi == '3' && $index !== false) {
                                                                        array_splice($pamongDps[$value->id], $index, 1);
                                                                    }
                                                                }


                                                                $id_dtl[$value->id] = $detildis->id;
                                                                $id_jns[$value->id] = $detildis->jenis_disposisi;


                                                            ?>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <td class="text-center">
                                            <a href="<?php echo e(route('bo.surat.disposisi.show', $value['id_surat'])); ?>" target="blank" class="btn btn-primary">
                                                <i class="bi bi-file-earmark"></i>
                                            </a>
                                        </td>
                                        <td class="text-center">
                                            <div class="d-flex justify-content-evenly">
                                                <button data-bs-toggle="modal" data-bs-target="#dispos_<?php echo e($value->id); ?>" class="btn btn-success" type="submit">
                                                    <i class="bi bi-diagram-2"></i> Disposisikan
                                                </button>

                                                <!-- ini bagian modal disposisi -->
                                                <div class="modal fade" id="dispos_<?php echo e($value->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-lg modal-dialog-scrollable">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Disposisi Surat <?php echo e($value->suratMasuk->nomor_surat); ?></h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="container">
                                                                    <div class="row border-bottom p-3">
                                                                        <div class="col">
                                                                            <p><b> Mohon untuk mengecek surat <?php echo e($value->suratMasuk->nomor_surat); ?> terlebih dahulu sebelum melakukan disposisi surat atau mengembalikan surat.</b> Langkah ini akan membantu memastikan bahwa semua informasi yang diperlukan telah dipertimbangkan dengan baik sebelum tindakan selanjutnya diambil.</p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                                <button data-bs-toggle="modal" data-bs-target="#kembalikan_<?php echo e($value->id); ?>" type="button" class="btn btn-danger">
                                                                    Kembalikan
                                                                </button>
                                                                <?php if($id_jns[$value->id] != 'PLK'): ?>
                                                                <button data-bs-toggle="modal" data-bs-target="#teruskan_<?php echo e($value->id); ?>" type="button" class="btn btn-success">
                                                                    Teruskan
                                                                </button>
                                                                <?php endif; ?>

                                                                <button data-bs-toggle="modal" data-bs-target="#laksanakan_<?php echo e($value->id); ?>" type="button" class="btn btn-primary">
                                                                    Laksanakan
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- modal disposisi tolak-->
                                                <div class="modal fade" id="teruskan_<?php echo e($value->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-lg modal-dialog-scrollable">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Teruskan Surat <?php echo e($value->suratMasuk->nomor_surat); ?></h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <form method="POST" action="<?php echo e(route('bo.surat.disposisi.update', $id_dtl[$value->id])); ?>">
                                                                <?php echo method_field('PUT'); ?>
                                                                <?php echo csrf_field(); ?>
                                                            <div class="modal-body">
                                                                <div class="container">


                                                                    <div class="row mb-3">
                                                                        <label for="Kepada" class="col-sm-3 col-form-label">Kepada</label>
                                                                        <div class="col-sm-9">
                                                                            <select id="Kepada" name="kepada" class="form-select" required>
                                                                                <option value="" disabled selected>Pilih Pejabat yang Menerima Surat</option>
                                                                                <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php if(in_array($jabat['id'], $pamongDps[$value->id])): ?>
                                                                                    <?php else: ?>
                                                                                    <option value="<?php echo e($jabat['id'].'/'.$jabat['jabatan']); ?>"><?php echo e($jabat['nama'] . ' ( ' . $jabat['jabatan'] . ' )'); ?></option>
                                                                                    <?php endif; ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row mb-3">
                                                                        <label for="jenis_disposisi" class="col-sm-3 col-form-label">Tipe Disposisi</label>
                                                                        <div class="col-sm-9">
                                                                            <select id="jenis_disposisi" name="jenis_disposisi" class="form-select" required>
                                                                                <option value="" disabled selected>Pilih Tipe Disposisi</option>
                                                                                    <option value="TRS">Teruskan</option>
                                                                                    <option value="PLK">Pelaksana</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row mb-3">
                                                                        <label for="catatan" class="col-sm-3 col-form-label">Catatan</label>
                                                                        <div class="col-sm-9">
                                                                            <textarea name="catatan" class="form-control" id="catatan" rows="5"></textarea>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-success">
                                                                    Teruskan
                                                                </button>
                                                            </div>
                                                        </form>
                                                        </div>
                                                    </div>
                                                </div>

                                                <?php if($id_jns[$value->id] != 'PLK'): ?>
                                                <!-- modal disposisi kembalikan-->
                                                <div class="modal fade" id="kembalikan_<?php echo e($value->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-lg modal-dialog-scrollable">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Kembalikan Surat <?php echo e($value->suratMasuk->nomor_surat); ?></h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <form method="POST" action="<?php echo e(route('bo.surat.disposisi.destroy', $id_dtl[$value->id])); ?>">
                                                                <?php echo method_field('delete'); ?>
                                                                <?php echo csrf_field(); ?>
                                                            <div class="modal-body">
                                                                <div class="container">


                                                                    <div class="row mb-3">
                                                                        <div class="col">
                                                                            <p>Berikan catatan mengapa Anda mengembalikan Surat <?php echo e($value->suratMasuk->nomor_surat); ?></p>
                                                                        </div>
                                                                    </div>

                                                                    <div class="row mb-3">
                                                                        <label for="catatan" class="col-sm-3 col-form-label">Catatan</label>
                                                                        <div class="col-sm-9">
                                                                            <textarea name="catatan" class="form-control" id="catatan" rows="5" required></textarea>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-danger">
                                                                    Kembalikan
                                                                </button>
                                                            </div>
                                                        </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endif; ?>

                                                <!-- modal disposisi laksanakan-->
                                                <div class="modal fade" id="laksanakan_<?php echo e($value->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-lg modal-dialog-scrollable">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Laporan Pelaksanaan Surat <?php echo e($value->suratMasuk->nomor_surat); ?></h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <form method="POST" action="<?php echo e(route('bo.surat.disposisi.executor_imp', $id_dtl[$value->id])); ?>">
                                                                <?php echo method_field('PUT'); ?>
                                                                <?php echo csrf_field(); ?>
                                                            <div class="modal-body">
                                                                <div class="container">

                                                                    <div class="row mb-3">
                                                                        <div class="col">
                                                                            <p>Berikan catatan mengapa Anda mengembalikan Surat <?php echo e($value->suratMasuk->nomor_surat); ?></p>
                                                                        </div>
                                                                    </div>

                                                                    <div class="row mb-3">
                                                                        <label for="catatan" class="col-sm-3 col-form-label">Catatan</label>
                                                                        <div class="col-sm-9">
                                                                            <textarea name="catatan" class="form-control" id="catatan" rows="5" required></textarea>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-primary">
                                                                    Laksanakan
                                                                </button>
                                                            </div>
                                                        </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- End Table with hoverable rows -->

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bo.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_sentolo\sentolo_gab_si\resources\views/bo/page/surat/disposisi/index.blade.php ENDPATH**/ ?>