<?php $__env->startSection('content'); ?>
	<div class="pagetitle">
        <h1><?php echo e($title); ?></h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/admin/e-surat/dashboard">Home</a></li>
                <li class="breadcrumb-item active"><?php echo e($title); ?></li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section">
        <div class="row">

            <div class="col-xxl-4 col-md-4">
                <div class="card info-card sales-card">

                <div class="card-body">
                    <h5 class="card-title">Jumlah Surat Keluar <span>| <?php echo e($thn_ini); ?></span></h5>

                    <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle px-3 py-2 text-bg-info d-flex align-items-center justify-content-center">
                        <i class="bi bi-envelope fs-2"></i>
                    </div>
                    <div class="ps-3">
                        <h3><?php echo e($data_graf['jum_surat_keluar']); ?></h3>
                    </div>
                    </div>
                </div>

                </div>
            </div>

            <div class="col-xxl-4 col-md-4">
                <div class="card info-card sales-card">

                <div class="card-body">
                    <h5 class="card-title">Jumlah Surat Masuk <span>| <?php echo e($thn_ini); ?></span></h5>

                    <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle px-3 py-2 text-bg-success d-flex align-items-center justify-content-center">
                        <i class="bi bi-envelope-open fs-2"></i>
                    </div>
                    <div class="ps-3">
                        <h3><?php echo e($data_graf['jum_surat_masuk']); ?></h3>
                    </div>
                    </div>
                </div>

                </div>
            </div>

            <div class="col-xxl-4 col-md-4">
                <div class="card info-card sales-card">

                <div class="card-body">
                    <h5 class="card-title">Jumlah Penduduk <span>| <?php echo e($thn_ini); ?></span></h5>

                    <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle px-3 py-2 text-bg-primary d-flex align-items-center justify-content-center">
                        <i class="bi bi-people fs-2"></i>
                    </div>
                    <div class="ps-3">
                        <h3><?php echo e($data_graf['jum_penduduk']); ?></h3>
                    </div>
                    </div>
                </div>

                </div>
            </div>
        </div>


        <!-- ini bagian chart -->
        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Surat Keluar Diproses</h5>
                    <canvas id="surat_keluar" style="max-height: 400px;"></canvas>
                    <!-- End Bar CHart -->
                </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Surat Masuk</h5>
                    <canvas id="surat_masuk" style="max-height: 400px;"></canvas>
                    <!-- End Bar CHart -->
                </div>
                </div>
            </div>


            <div class="col-lg-6">
                <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Data Penduduk</h5>

                    <!-- Pie Chart -->
                    <canvas id="data_penduduk" style="max-height: 400px;"></canvas>
                    <!-- End Pie CHart -->

                </div>
                </div>
            </div>


            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Arsip Surat')): ?>
            <div class="col-lg-6">
                <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Data Arsip <?php echo e($thn_ini); ?></h5>
                    <!-- Pie Chart -->
                    <canvas id="arsip_thn_ini" style="max-height: 400px;"></canvas>
                    <!-- End Pie CHart -->
                </div>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </section>


<script>
    document.addEventListener("DOMContentLoaded", () => {
      new Chart(document.querySelector('#data_penduduk'), {
        type: 'pie',
        data: {
          labels: [
            <?php $__currentLoopData = $data_graf['graf_penduduk']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                '<?php echo e($penduduk->jenis_kelamin); ?>',
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          ],
          datasets: [{
            label: 'My First Dataset',
            data: [
                <?php $__currentLoopData = $data_graf['graf_penduduk']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($penduduk->jumlah); ?>,
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
            backgroundColor: [
              'rgb(255, 99, 132)',
              'rgb(54, 162, 235)'
            ],
            hoverOffset: 4
          }]
        }
      });
    });

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Arsip Surat')): ?>
    document.addEventListener("DOMContentLoaded", () => {
      new Chart(document.querySelector('#arsip_thn_ini'), {
        type: 'pie',
        data: {
          labels: [
            <?php $__currentLoopData = $data_graf['graf_arsip']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arsip_thn_ini): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                '<?php echo e($arsip_thn_ini->jenis_surat_2); ?>',
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          ],
          datasets: [{
            label: 'My First Dataset',
            data: [
                <?php $__currentLoopData = $data_graf['graf_arsip']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arsip_thn_ini): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($arsip_thn_ini->jumlah); ?>,
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
            backgroundColor: [
              'rgb(255, 99, 132)',
              'rgb(54, 162, 235)'
            ],
            hoverOffset: 4
          }]
        }
      });
    });
    <?php endif; ?>


    document.addEventListener("DOMContentLoaded", () => {
      new Chart(document.querySelector('#surat_keluar'), {
        type: 'bar',
        data: {
          labels: [
            <?php $__currentLoopData = $data_graf['graf_surat_keluar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat_keluar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                '<?php echo e($surat_keluar->jenis_surat); ?>',
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
          datasets: [{
            label: 'Surat Keluar',
            data: [
                <?php $__currentLoopData = $data_graf['graf_surat_keluar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat_keluar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($surat_keluar->jumlah); ?>,
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(255, 159, 64, 0.2)',
              'rgba(255, 205, 86, 0.2)',
              'rgba(75, 192, 192, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(153, 102, 255, 0.2)',
              'rgba(201, 203, 207, 0.2)'
            ],
            borderColor: [
              'rgb(255, 99, 132)',
              'rgb(255, 159, 64)',
              'rgb(255, 205, 86)',
              'rgb(75, 192, 192)',
              'rgb(54, 162, 235)',
              'rgb(153, 102, 255)',
              'rgb(201, 203, 207)'
            ],
            borderWidth: 1
          }]
        },
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          }
        }
      });
    });

    document.addEventListener("DOMContentLoaded", () => {
      new Chart(document.querySelector('#surat_masuk'), {
        type: 'bar',
        data: {
          labels: [
            <?php $__currentLoopData = $data_graf['graf_surat_masuk']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat_masuk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                '<?php echo e($surat_masuk->status_text); ?>',
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
          datasets: [{
            label: 'Surat Masuk',
            data: [
                <?php $__currentLoopData = $data_graf['graf_surat_masuk']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat_masuk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($surat_masuk->jumlah); ?>,
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(255, 159, 64, 0.2)',
              'rgba(255, 205, 86, 0.2)',
              'rgba(75, 192, 192, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(153, 102, 255, 0.2)',
              'rgba(201, 203, 207, 0.2)'
            ],
            borderColor: [
              'rgb(255, 99, 132)',
              'rgb(255, 159, 64)',
              'rgb(255, 205, 86)',
              'rgb(75, 192, 192)',
              'rgb(54, 162, 235)',
              'rgb(153, 102, 255)',
              'rgb(201, 203, 207)'
            ],
            borderWidth: 1
          }]
        },
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          }
        }
      });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('bo.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_sentolo\sentolo_gab_si\resources\views/bo/page/surat/dashboard/index.blade.php ENDPATH**/ ?>