<?php $__env->startSection('content'); ?>

    <div class="pagetitle">
        <h1>Hak Akses</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Kepegawaian</a></li>
                <li class="breadcrumb-item active">Hak Akses</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section">
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="card-title">Data Hak Akses</h5>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_create')): ?>
                            <a class="btn btn-primary" href="<?php echo e(route('bo.pegawai.role_management.create')); ?>">Tambah</a>
                            <?php endif; ?>
                        </div>

                        <!-- Table with hoverable rows -->
                        <table id="user_table" class="table table-hover content_table datatable">
                            <thead>
                                <tr>
                                    <th scope="col">No.</th>
                                    <th scope="col">Role</th>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['role_edit', 'role_delete'])): ?>
                                    <th scope="col">Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($role['name']); ?></td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['role_edit', 'role_delete'])): ?>
                                        <td>
                                            <form action="<?php echo e(route('bo.pegawai.role_management.destroy', $role->id)); ?>" method="POST">
                                            
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_edit')): ?>
                                            <a class="btn btn-warning" href="<?php echo e(route('bo.pegawai.role_management.edit', $role->id)); ?>"><i class="fa-solid fa-pen-to-square"></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_delete')): ?>
                                             <button class="btn btn-danger" type="submit" href="/surat-kbm/<?php echo e($role->id); ?>/delete"><i class="fa-regular fa-trash-can"></i></button>
                                             </form>
                                             <?php endif; ?>
                                        </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </tbody>
                        </table>
                        <!-- End Table with hoverable rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('bo.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_sentolo\sentolo_gab_si\resources\views/bo/page/pegawai/role/index.blade.php ENDPATH**/ ?>