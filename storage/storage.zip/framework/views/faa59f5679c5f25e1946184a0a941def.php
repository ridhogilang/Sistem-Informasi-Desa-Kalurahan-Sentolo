<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
            <a class="nav-link <?php echo e(($title == "Dashboard") ? '' : 'collapsed'); ?>" href="/">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>
        </li><!-- End Dashboard Nav -->

        </li><!-- End Nav -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['user_list', 'user_create', 'user_edit', 'user_delete'])): ?>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('admin/pegawai/user_management*') ? '' : 'collapsed'); ?>" href="<?php echo e(route('bo.pegawai.user_management.index')); ?>">
                <i class="fa-regular fa-envelope-open"></i>
                <span>Pegawai</span>
            </a>
        </li>
        <?php endif; ?>
        <!-- End Surat Masuk Nav -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['role_list', 'role_create', 'role_edit', 'role_delete'])): ?>
        <li class="nav-item">
            <a class="nav-link  <?php echo e(request()->is('admin/pegawai/role_management*') ? '' : 'collapsed'); ?>" href="<?php echo e(route('bo.pegawai.role_management.index')); ?>">
                <i class="bx bx-lock"></i>
                <span>Role</span>
            </a>
        </li>
        <?php endif; ?>
        <!-- End Surat Masuk Nav -->

        <li class="nav-heading">Pages</li>

        <li class="nav-item">
            <a class="nav-link <?php echo e(($title == "Profile") ? '' : 'collapsed'); ?>" href="/profile">
                <i class="bi bi-person"></i>
                <span>Profile</span>
            </a>
        </li><!-- End Profile Page Nav -->

        <li class="nav-item">
            <a class="nav-link <?php echo e(($title == "Register") ? '' : 'collapsed'); ?>" href="/register">
                <i class="bi bi-card-list"></i>
                <span>Register</span>
            </a>
        </li><!-- End Register Page Nav -->

        <li class="nav-item">
            <a class="nav-link <?php echo e(($title == "Login") ? '' : 'collapsed'); ?>" href="/login">
                <i class="bi bi-box-arrow-in-right"></i>
                <span>Login</span>
            </a>
        </li><!-- End Login Page Nav -->

    </ul>

</aside>
<?php /**PATH D:\project_sentolo\sentolo_gab_si\resources\views/bo/partial/sidebar_pegawai.blade.php ENDPATH**/ ?>